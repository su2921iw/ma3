vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 Apr 2002 09:44:00 -0000
vti_extenderversion:SR|5.0.2.2623
vti_backlinkinfo:VX|antonia.htm thankyou.html maskitaliastores_se.htm maskitaliaheadquarters.htm massimo.htm maskitaliastores.htm maskhistory.htm daniele.htm eventsparties.htm marino.htm michela.htm wholesale.htm orderform.htm lucia.htm form.html mario.htm venetianmask.htm masks.htm index.htm sitemap.htm bijan.htm orderform_confirm.htm open.htm venetianmasks.htm
vti_author:SR|www.maskitalia.com
vti_modifiedby:SR|www.maskitalia.com
vti_nexttolasttimemodified:TR|29 Apr 2002 09:44:00 -0000
vti_timecreated:TR|16 Jul 2003 21:35:19 -0000
vti_syncwith_localhost\\d\:\\mywebs\\mask_publish/d\:/mywebs/mask_publish:TR|29 Apr 2002 09:44:00 -0000
vti_cacheddtm:TX|05 Sep 2002 04:54:15 -0000
vti_filesize:IR|11125
